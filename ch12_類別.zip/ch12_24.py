# ch12_24.py
print('ch12_24.py module name = ', __name__)



