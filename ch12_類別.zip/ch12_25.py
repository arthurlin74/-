# ch12_25.py
def myFun():
    print("__name__ == __main__")
if __name__ == '__main__':
    myFun()





