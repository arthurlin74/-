# ch12_27.py
import ch12_25



