
# 資料型態

print(type(10))
print(type(2.718))
print(type('Hello'))

# 變數

x = 10
print(x)
x = 100
print(x)
y = 3.14
print(x*y)
print(type(x*y))
