
# 清單

a = [1, 2, 3, 4, 5]
print(a)
print(len(a))
print(a[0])
print(a[4])
a[4] = 99
print(a)

print(a[0:2])
print(a[1:])
print(a[:3])
print(a[:-1])
print(a[:-2])

# 字典型態

me = {'height':180}
print(me['height'])

me['weight'] = 70
print(me)
print(me['weight'])

# 布林型態

hungry = True
sleepy = False
print(type(hungry))
print(not hungry)
print(hungry and sleepy)
print(hungry or sleepy)










