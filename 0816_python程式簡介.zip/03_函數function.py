
# 函數

def hello():
    print('Hello World!')

hello()


def hello(object):
    print('Hello, '+ object + '!')

hello('cat')
