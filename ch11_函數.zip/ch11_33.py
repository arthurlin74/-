# ch11_33.py
# 定義lambda函數
product = lambda x, y: x * y

# 輸出相乘結果
print(product(5, 10))

