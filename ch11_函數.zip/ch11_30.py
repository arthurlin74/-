# ch11_30.py
def defmsg( ):
    msg = 'pringmsg variable'

print(msg)         # 主程式列印區域變數產生錯誤



