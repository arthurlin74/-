# ch11_38.py
def fun(arg):
    pass

