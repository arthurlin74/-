# ch11_32.py
# 定義lambda函數
product = lambda x, y: x * y

# 輸出變數的積
print(product(5, 10))



