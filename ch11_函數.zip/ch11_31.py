# ch11_31.py
# 定義lambda函數
square = lambda x: x ** 2

# 輸出平方值
print(square(10))

