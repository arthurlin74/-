# ch11_29.py
def defmsg( ):
    msg = 'pringmsg variable'

def printmsg( ):
    print(msg)      # 列印defmsg( )函數定義的區域變數

printmsg( )         # 呼叫printmsg( )



